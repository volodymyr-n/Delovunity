var config = {

    // When load 'requirejs' always load the following files also
    deps: [
        "Delovunity_OutOfStock/js/catalog_product_out_of_stock"
    ]
};
